---
#date: 2024-09-21
title: Members
---

### MPhil & MEng Students

- Yiwen Huang (2021~, MPhil)
- Chao Peng (2022~, MPhil)
- Zishu Qin (2023~, MPhil)
- Hibo Wang (2022~, MEng)
- Yuhan He (2022~, MEng)
- Zelong Wang (2022~, MEng)
- Xinhao Liu (2022~, MEng)
- Hongbo Shi (2022~, MEng)
- Zhihao Shao (2022~, MEng)
- Jin Cui (2023~, MEng)
- Tianhao Li (2023~, MEng)
- Yue Pan (2023~, MEng)
- Yijia Zhong (2023~, MEng)
- Yuanfan Ma (2023~, MEng)


### Undergraduate Students

- Youran Ye (2023~)
- Yinuo Wang (2023~)
- Lanqing Jia (2023~)
- Shi Chen (2023~)
- Xingyu Zhao (2023~)


### Alumni

- Dongyang Zhao (2020~2023, MPhil, Tecent)
- Yangji He (2020~2023, MPhil, ByteDance)
- Boan He (2020~2023, MEng, DJI)
- Haotong Gong (2021~2024, MEng, Tecent)
- Weihan Liang (2021~2024, MEng, WeChat)
- Ruize Xu (2021~2024, MEng, Huawei)
- Xianbing Liang (2021~2024, MEng, NetEase)
- Yubo Wang (2021~2024, MEng, Sensetime)
- Shilong Dong (2022~2024, UnGrad, NYU Courant)
- Xiaowen Qiu (2022~2024, UnGrad, UMass Amherst)
- Zhenghao Ji (2020~2021, UnGrad, Sensetime)
- Ziyang Song (2020~2021, UnGrad, Tsinghua University)


