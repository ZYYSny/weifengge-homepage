---
# An instance of the Pages widget.
# Documentation: https://wowchemy.com/docs/page-builder/
widget: blank

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 60

active: false

title: Awards
subtitle:
#ex_link: '/news'  
#ex_link_title: 'All news»'  


design:
  # Choose a view for the listings:
  view: compact
  columns: '2'
---

🏆 Shanghai Jiao Tong University Outstanding Engineer Reserve Talent Training Program, 2022

🏆 The First Prize in Anti-UAV 2020 Challenge, CVPR Workshops 2020.

🏆 The First Prize in VisDrone 2019 Task 3: Single-object Tracking Challenge, ICCV Workshops 2019.

🏆 The First Prize in the Post-graduate Group of the Eighth MathorCup Mathematical Modeling Challenge 2018.

🏆 The First Prize in the China Post-graduate Mathematical Contest in Modeling 2017.

🏆 The Honor of “Excellent Graduate” of the Hunan Province 2016.

🏆 The Second Prize in the American University Students Mathematical Contest in Modeling 2016.

🏆 The National Scholarship 2015.

🏆 The Second Prize in the National University Students Mathematical Modeling Contest 2015.

🏆 The First Prize in the National University Students Mathematical Modeling Contest 2014.

🏆 The National Encouragement Scholarship 2013.
